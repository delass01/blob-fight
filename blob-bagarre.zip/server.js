const express = require("express");
const http = require("http");
const socketIO = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));

let players = {};

io.on("connection", (socket) => {
  console.log("Nouveau joueur :", socket.id);

  players[socket.id] = {
    x: Math.random() * 800,
    y: Math.random() * 600,
    radius: 20,
    color: "#" + Math.floor(Math.random()*16777215).toString(16),
  };

  socket.emit("currentPlayers", players);
  socket.broadcast.emit("newPlayer", { id: socket.id, data: players[socket.id] });

  socket.on("move", (data) => {
    if (players[socket.id]) {
      players[socket.id].x += data.x;
      players[socket.id].y += data.y;
    }
  });

  socket.on("disconnect", () => {
    console.log("Joueur parti :", socket.id);
    delete players[socket.id];
    io.emit("removePlayer", socket.id);
  });
});

setInterval(() => {
  io.emit("playerUpdates", players);
}, 1000 / 30);

server.listen(PORT, () => console.log(`Serveur lancé sur le port ${PORT}`));
